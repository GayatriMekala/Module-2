import {Component} from '@angular/core'
import {Employee} from './Employee';


@Component({
    selector:'emp-app',
    templateUrl: `./app.employee.html`
})
export class EmployeeComponent{
    

    //part of two way binding

    empId:number;
    employeeName:string;
    employeePrice:number;
    employeeDescription:string;

    
    uId:number;
    uName:string;
    uPrice:number;
    uDescription:string;


    employeedata:Employee[]=[
        {empId:1001,employeeName:"Rahul",employeePrice:9000,employeeDescription:"Java"},
        {empId:1002,employeeName:"Sachin",employeePrice:19000,employeeDescription:"ORA APPS"},
        {empId:1003,employeeName:"Vikas",employeePrice:29000,employeeDescription:"DI"}
];
    addAll(){
        this.employeedata.push({
            empId:this.empId,
            employeeName:this.employeeName,
            employeePrice:this.employeePrice,
            employeeDescription:this.employeeDescription
        });
        //this.addMsg="Data Inserted";
    }

    updateOne(dataupdate){
        this.uId=dataupdate.empId;
        this.uName=dataupdate.employeeName;
        this.uPrice=dataupdate.employeePrice;
        this.uDescription=dataupdate.employeeDescription;

    }
    update(){
        for(var i=0;i<this.employeedata.length;i++)
        {
            if(this.employeedata[i].empId==this.uId)
            {
                this.employeedata[i].empId=this.uId;
                this.employeedata[i].employeeName=this.uName;
                this.employeedata[i].employeePrice=this.uPrice;
                this.employeedata[i].employeeDescription=this.uDescription;
            }
        }

}

delete(data){
    for(var i=0;i<this.employeedata.length;i++)
        {
            if(this.employeedata[i].empId==data.empId)
            {
                this.employeedata.splice(i,1);
            }
        }
}

//delete(delId:number):any{
//alert(delId);
//this.employee data.splice(delId,1);}//
/*
addMobile():any{
	alert(this.temp);
	this.mobile data.push(this.temp);
	this.temp={};
	}

*/


}